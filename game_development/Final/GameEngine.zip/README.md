hi                                      

run with

```
./bin/game
```

nice

you may need to

```
chmod +x ./bin/game
```

n i c e
