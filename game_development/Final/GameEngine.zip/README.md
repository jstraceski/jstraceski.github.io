hi                                      



run with

```
./bin/game
```
or 

build with
```
make
```
and run with 
```
./bin/game
```

or 
build with
```
mkdir build
cd build; CXX=clang++ cmake ..; make; cd ..
./build/engine_proj
```

nice

you may need to

```
chmod +x ./bin/game
```
or
```
chmod +x ./bin/engine_proj
```

n i c e
