# Spiew!

Our little sprite viewer!

## How to run:
```
$ make run

or

$ ./spedit -w -h -W -H <options> <filepath>
```
Options:
- w width of the sprite
- h height of the sprite
- W width of the sprite sheet
- H height of the sprite sheet
- f number of frames, defaults to W x H
