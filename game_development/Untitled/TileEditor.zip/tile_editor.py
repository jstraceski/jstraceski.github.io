#! /usr/bin/env python3
from copy import deepcopy
import pygame
from Vector import Vector
import math
import json
import tkinter as tk
from tkinter import filedialog

select_id = 0
data = {'board_x': 20, 'board_y': 10, 'tile_w': 64, 'tile_h': 64, 'space_x': 0, 'space_y': 0}
gui_data = {}
tile_scale = 1
snap_pos = Vector(100, 100)
pos = (0, 0)
_rad = 5
sel_id = 1
running = 1

tile_data = None

pressed_last = False
board_data = [[-1] * data['board_y'] for _ in range(data['board_x'])]

offset = Vector(0, 0)

s_size = (1080, 720)
b_scale = 1

font = None
file_path = None

div = 0.4

editWindow = pygame.Rect(div * s_size[0], 0.05 * s_size[1], (1.0 - div) * s_size[0], 0.95 * s_size[1])
menuWindow = pygame.Rect(0, 0, div * s_size[0], s_size[1])
fullWindow = pygame.Rect(0, 0, s_size[0], s_size[1])

file_path_window = {'text': '', 'shape': pygame.Rect(20 * b_scale, 10 * b_scale, 0.95 * s_size[0], 20 * b_scale)}
item_lookup = {}
last_key_out = {}
max_id = None


def loadJson(path=None):
    global board_data
    if path is None:
        root = tk.Tk()
        types = [('map_data', '*.json')]
        path = filedialog.askopenfilename(filetypes=types, defaultextension=types)
        root.destroy()

    if path is None or path is False or not path or path == ():
        return
    try:
        datafile = open(path, "r")
        # magic happens here to make it pretty-printed
        out = json.loads(datafile.read())
        datafile.close()

        data.update(out)
        board_data = out['board']
        updateTileData(new_file_path=out['tilemap_path'])
    except Exception as e:
        print(path, e)
        print("Error Loading save file.")


def saveJson():
    global data
    out = {}

    root = tk.Tk()
    types = [('map_data', '*.json')]
    path = filedialog.asksaveasfilename(filetypes=types, defaultextension=types)
    root.destroy()

    if path is None or path is False or not path or path == ():
        return

    out.update(data)
    out['tilemap_path'] = file_path
    out['board'] = board_data

    datafile = open(path, "w")
    # magic happens here to make it pretty-printed
    datafile.write(json.dumps(out, indent=4, sort_keys=True))
    print(json.dumps(out, indent=4, sort_keys=True))
    datafile.close()


def updateTileData(newFile=False, width=None, height=None, space_x=None, space_y=None, new_file_path=None):
    global tile_data, data, file_path, gui_data

    width = data['tile_w'] if width is None else width
    height = data['tile_h'] if height is None else height
    space_x = data['space_x'] if space_x is None else space_x
    space_y = data['space_y'] if space_y is None else space_y

    if newFile or new_file_path is not None:
        if new_file_path is None:
            root = tk.Tk()
            foo = filedialog.askopenfilename()
            root.destroy()
        else:
            foo = new_file_path

        if foo is None or foo is False or not foo or foo == ():
            return

        file_path_window["text"] = foo
        try:
            tile_data = pygame.image.load(foo)
        except:
            file_path_window["color"] = (150, 80, 80)
            return

    if tile_data == None:
        return

    gui_data['text_list'] = list(gui_data['text_list_start'])
    gui_data['buttons'] = list(gui_data['buttons_start'])

    size = tile_data.get_size()
    x_count = math.floor(float(size[0] + space_x) / (width + space_x))
    y_count = math.floor(float(size[1] + space_y) / (height + space_y))

    left_just = 20
    spacing = 2
    pos = Vector(left_just, 140)
    tile_count = 0

    for h in range(y_count):
        for w in range(x_count):
            if pos.x + width >= menuWindow.w:
                pos.x = left_just
                pos.y = pos.y + height + spacing

            def set_sel(n):
                global sel_id
                sel_id = n

            current_count = int(tile_count)

            item = {'image': tile_data, 'pos': pos.toTup(),
                    'shape': pygame.Rect(pos.x, pos.y, width, height),
                    'clip': pygame.Rect(w * (width + space_x), h * (height + space_y), width, height),
                    'function': lambda i: set_sel(i["id"]),
                    'id': tile_count}
            item_lookup[current_count] = item

            gui_data['text_list'] += [item]
            gui_data['buttons'] += [item]

            pos += Vector(width + spacing, 0)
            tile_count += 1

    file_path = file_path_window["text"]
    file_path_window["color"] = (80, 150, 80)


def updateTile(dx, dy, a='tile_w', b='tile_h'):
    global board_data
    nx = data[a] + dx < 0 if 0 else data[a] + dx
    ny = data[b] + dy < 0 if 0 else data[b] + dy

    if a == 'tile_w' and b == 'tile_h':
        updateTileData(False, nx, ny)
    else:
        updateTileData(False, space_x=nx, space_y=ny)

    data[a] = nx
    data[b] = ny


def updateDims(dx, dy, a='board_x', b='board_y'):
    global board_data
    nx = data[a] + dx < 0 if 0 else data[a] + dx
    ny = data[b] + dy < 0 if 0 else data[b] + dy

    new_board = [[-1] * ny for _ in range(nx)]

    for x in range(min(data[a], nx)):
        for y in range(min(data[b], ny)):
            new_board[x][y] = board_data[x][y]

    board_data = new_board

    data[a] = nx
    data[b] = ny


tile_id = {'text': '', 'shape': pygame.Rect(20 * b_scale, s_size[1] - 40, 60 * b_scale, 20 * b_scale),
           "update": lambda _: f"id: {sel_id}"}
loadFile = {'text': 'Load Map Image', 'shape': pygame.Rect(210 * b_scale, 40 * b_scale, 160 * b_scale, 20 * b_scale),
            "function": lambda _: updateTileData(True)}
export = {'text': 'export', 'shape': pygame.Rect(320 * b_scale, 65 * b_scale, 80 * b_scale, 20 * b_scale),
          "function": lambda _: saveJson()}
load_json_button = {'text': 'Load Json', 'shape': pygame.Rect(210 * b_scale, 65 * b_scale, 100 * b_scale, 20 * b_scale),
                    "function": lambda _: loadJson()}

text_tile_x = {'text': '', 'shape': pygame.Rect(20 * b_scale, 40 * b_scale, 80 * b_scale, 20 * b_scale),
               'update': lambda _: f"x: {data['board_x']}"}
text_tile_y = {'text': '', 'shape': pygame.Rect(120 * b_scale, 40 * b_scale, 80 * b_scale, 20 * b_scale),
               'update': lambda _: f"y: {data['board_y']}"}

p_x = {'text': '+', 'shape': pygame.Rect(20 * b_scale, 65 * b_scale, 20 * b_scale, 20 * b_scale),
       'function': lambda _: updateDims(1, 0)}
m_x = {'text': '-', 'shape': pygame.Rect(45 * b_scale, 65 * b_scale, 20 * b_scale, 20 * b_scale),
       'function': lambda _: updateDims(-1, 0)}

p_y = {'text': '+', 'shape': pygame.Rect(120 * b_scale, 65 * b_scale, 20 * b_scale, 20 * b_scale),
       'function': lambda _: updateDims(0, 1)}
m_y = {'text': '-', 'shape': pygame.Rect(145 * b_scale, 65 * b_scale, 20 * b_scale, 20 * b_scale),
       'function': lambda _: updateDims(0, -1)}

text_tile_spacing_x = {'text': '', 'shape': pygame.Rect(210 * b_scale, 90 * b_scale, 80 * b_scale, 20 * b_scale),
                       'update': lambda _: f"s_x: {data['space_x']}"}
text_tile_spacing_y = {'text': '', 'shape': pygame.Rect(300 * b_scale, 90 * b_scale, 80 * b_scale, 20 * b_scale),
                       'update': lambda _: f"s_y: {data['space_y']}"}

p_sx = {'text': '+', 'shape': pygame.Rect(210 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
        'function': lambda _: updateTile(1, 0, 'space_x', 'space_y')}
m_sx = {'text': '-', 'shape': pygame.Rect(235 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
        'function': lambda _: updateTile(-1, 0, 'space_x', 'space_y')}

p_sy = {'text': '+', 'shape': pygame.Rect(300 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
        'function': lambda _: updateTile(0, 1, 'space_x', 'space_y')}
m_sy = {'text': '-', 'shape': pygame.Rect(325 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
        'function': lambda _: updateTile(0, -1, 'space_x', 'space_y')}

text_tile_width = {'text': '', 'shape': pygame.Rect(20 * b_scale, 90 * b_scale, 80 * b_scale, 20 * b_scale),
                   'update': lambda _: f"w: {data['tile_w']}"}
text_tile_height = {'text': '', 'shape': pygame.Rect(120 * b_scale, 90 * b_scale, 80 * b_scale, 20 * b_scale),
                    'update': lambda _: f"h: {data['tile_h']}"}

p_width = {'text': '+', 'shape': pygame.Rect(20 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
           'function': lambda _: updateTile(1, 0)}
m_width = {'text': '-', 'shape': pygame.Rect(45 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
           'function': lambda _: updateTile(-1, 0)}

p_height = {'text': '+', 'shape': pygame.Rect(120 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
            'function': lambda _: updateTile(0, 1)}
m_height = {'text': '-', 'shape': pygame.Rect(145 * b_scale, 115 * b_scale, 20 * b_scale, 20 * b_scale),
            'function': lambda _: updateTile(0, -1)}

gui_data['buttons_start'] = [loadFile, export, p_width, m_width, p_height, m_height, p_x, p_y, m_x, m_y,
                             text_tile_spacing_x, text_tile_spacing_y, p_sx, m_sx, p_sy, m_sy, load_json_button]
gui_data['text_list_start'] = [file_path_window, loadFile, export, text_tile_x, text_tile_y, p_width, m_width, p_height,
                               m_height, text_tile_width, text_tile_height, p_x, p_y, m_x, m_y, tile_id,
                               text_tile_spacing_x, text_tile_spacing_y, p_sx, m_sx, p_sy, m_sy, load_json_button]

gui_data['text_list'] = list(gui_data['text_list_start'])
gui_data['buttons'] = list(gui_data['buttons_start'])


def draw_text(button, screen=None, font=None):
    if 'update' in button:
        button['text'] = button['update'](None)

    col = button['color'] if ('color' in button) else (155, 155, 155)

    if 'image' in button and 'clip' in button and 'pos' in button:
        screen.blit(button['image'], button['pos'], button['clip'])
    else:
        font_img = font.render(button['text'], True, (255, 255, 255))
        font_size = font_img.get_size()
        pygame.draw.rect(screen, col, button['shape'])
        screen.blit(font_img, (button['shape'].centerx - font_size[0] / 2, button['shape'].centery - font_size[1] / 2))


def draw(screen):
    global snap_pos, _rad, pos, offset, board_data, font

    screen.set_clip(editWindow)
    screen.fill((20, 20, 20))

    for w in range(data['board_x']):
        for h in range(data['board_y']):
            a1, a2 = Vector(data['tile_w'] * w, 0), Vector(data['tile_w'] * w, data['tile_h'] * (data['board_y'] - 1))
            b1, b2 = Vector(0, data['tile_h'] * h), Vector(data['tile_w'] * (data['board_x'] - 1), data['tile_h'] * h)
            a1 += offset
            a2 += offset
            b1 += offset
            b2 += offset

            pygame.draw.line(screen, (100, 100, 100), b1.toTup(), b2.toTup())
            pygame.draw.line(screen, (100, 100, 100), a1.toTup(), a2.toTup())

    for w in range(data['board_x']):
        for h in range(data['board_y']):
            if board_data[w][h] != -1:
                p = Vector(data['tile_w'] * w, data['tile_h'] * h) + offset
                if board_data[w][h] in item_lookup:
                    button_data = item_lookup[board_data[w][h]]
                    npos = p - Vector(data['tile_w'] / 2, data['tile_h'] / 2)
                    draw_text({'image': button_data['image'], 'clip': button_data['clip'], 'pos': npos.toTup()}, screen,
                              font)
                else:
                    # pygame.draw.circle(screen, (100, 255, 100), p.toTup(), _rad)
                    draw_text({'text': f"{board_data[w][h]}", 'shape': pygame.Rect(p.x - 5, p.y - 5, 10, 10)}, screen,
                              font)

    if sel_id in item_lookup:
        button_data = item_lookup[sel_id]
        npos = Vector(pos[0], pos[1]) - Vector(data['tile_w'] / 2, data['tile_h'] / 2)
        draw_text({'image': button_data['image'], 'clip': button_data['clip'], 'pos': npos.toTup()}, screen, font)
    else:
        pygame.draw.circle(screen, (255, 0, 0), pos, _rad)
    pygame.draw.circle(screen, (255, 255, 255), (snap_pos + offset).toTup(), _rad)

    screen.set_clip(fullWindow)

    [draw_text(t, screen=screen, font=font) for t in gui_data['text_list']]


def button_hit(button):
    mPos = pygame.mouse.get_pos()
    shape = button['shape']

    if shape.x <= mPos[0] <= shape.x + shape.width and shape.y <= mPos[1] <= shape.y + shape.height:
        if 'function' in button:
            button['function'](button)
        return True
    return False


def input():
    global pressed_last, snap_pos, pos, offset, board_data, running, last_key_out, sel_id
    evs = pygame.event.get()

    if any([True for e in evs if e.type == pygame.QUIT]):
        running = False

    pos = pygame.mouse.get_pos()
    edit_check = editWindow.collidepoint(pos)

    v_pos = (Vector(pos[0], pos[1]) - offset).toTup()
    sel_x = math.floor((v_pos[0] / data['tile_w']) + 0.5)
    sel_y = math.floor((v_pos[1] / data['tile_h']) + 0.5)

    if pygame.mouse.get_pressed(3)[0] and edit_check:
        snap_pos = Vector(sel_x * data['tile_w'], sel_y * data['tile_h'])

    if pygame.mouse.get_pressed(3)[0] and edit_check:
        if 0 <= sel_x < data['board_x'] and 0 <= sel_y < data['board_y']:
            board_data[sel_x][sel_y] = sel_id
    if pygame.mouse.get_pressed(3)[2] and edit_check:
        if 0 <= sel_x < data['board_x'] and 0 <= sel_y < data['board_y']:
            board_data[sel_x][sel_y] = -1

    key_out = pygame.key.get_pressed()
    speed = 2
    if key_out[pygame.K_w]:
        offset += Vector(0, speed)
    if key_out[pygame.K_s]:
        offset += Vector(0, -speed)
    if key_out[pygame.K_a]:
        offset += Vector(speed, 0)
    if key_out[pygame.K_d]:
        offset += Vector(-speed, 0)

    if key_out[pygame.K_e] and not last_key_out[pygame.K_e]:
        sel_id = max_id if max_id is not None and sel_id + 1 > max_id else sel_id + 1
    if key_out[pygame.K_q] and not last_key_out[pygame.K_q]:
        sel_id = 0 if sel_id - 1 < 0 else sel_id - 1

    last_key_out = deepcopy(key_out)

    clicked = any([True for e in evs if e.type == pygame.MOUSEBUTTONDOWN])

    if clicked:
        [button_hit(b) for b in gui_data['buttons']]


if __name__ == '__main__':
    import argparse
    import os

    parser = argparse.ArgumentParser(description='Tilemap Editor for Game.')
    parser.add_argument('--image', '-i', required=False, type=str, help='Path to an image file', default=None)
    parser.add_argument('--tile_width', '-tw', required=False, type=int, help='The width of the tile', default=64)
    parser.add_argument('--tile_height', '-th', required=False, type=int, help='The height of the tile', default=64)
    parser.add_argument('--board_width', '-bw', required=False, type=int, help='Tiles in the board lengthwise',
                        default=20)
    parser.add_argument('--board_height', '-bh', required=False, type=int, help='Tiles in the board vertically',
                        default=10)
    parser.add_argument('--spacing_width', '-sw', required=False, type=int, help='Spacing between tiles lengthwise',
                        default=0)
    parser.add_argument('--spacing_height', '-sh', required=False, type=int, help='Spacing between tiles vertically',
                        default=0)
    parser.add_argument('--level_path', '-l', required=False, type=str, help='Path to a .json level container',
                        default=None)

    args = parser.parse_args()

    data['board_x'] = args.board_width
    data['board_y'] = args.board_height
    data['tile_w'] = args.tile_width
    data['tile_h'] = args.tile_height
    data['space_x'] = args.spacing_width
    data['space_y'] = args.spacing_height

    if (args.image is not None):
        updateTileData(new_file_path=args.image)
    if (args.level_path is not None):
        loadJson(path=args.level_path)

    screen = pygame.display.set_mode(s_size)

    pygame.init()
    pygame.display.set_caption('path_setup')

    font = pygame.font.SysFont('Courier New', 16 * b_scale)

    while running:
        screen.fill((0, 0, 0))
        input()
        draw(screen)
        pygame.display.flip()
