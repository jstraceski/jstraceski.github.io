# A Tile Editing Tool
## Running the tool
Requires python 3 pygame and Tkinter.
Tkinter should already be installed.
If you have pip pygame can be installed with.
```bash
python -m pip install pygame
```
And then to run
```bash
python -m pip install pygame
```

## Usage

### Load an example
```
python tile_editor.py -l test.json
```

### All inputs
```
usage: tile_editor.py [-h] [--image IMAGE] [--tile_width TILE_WIDTH]
                      [--tile_height TILE_HEIGHT] [--board_width BOARD_WIDTH]
                      [--board_height BOARD_HEIGHT]
                      [--spacing_width SPACING_WIDTH]
                      [--spacing_height SPACING_HEIGHT]
                      [--level_path LEVEL_PATH]

Tilemap Editor for Game.

optional arguments:
  -h, --help            show this help message and exit
  --image IMAGE, -i IMAGE
                        Path to an image file
  --tile_width TILE_WIDTH, -tw TILE_WIDTH
                        The width of the tile
  --tile_height TILE_HEIGHT, -th TILE_HEIGHT
                        The height of the tile
  --board_width BOARD_WIDTH, -bw BOARD_WIDTH
                        Tiles in the board lengthwise
  --board_height BOARD_HEIGHT, -bh BOARD_HEIGHT
                        Tiles in the board vertically
  --spacing_width SPACING_WIDTH, -sw SPACING_WIDTH
                        Spacing between tiles lengthwise
  --spacing_height SPACING_HEIGHT, -sh SPACING_HEIGHT
                        Spacing between tiles vertically
  --level_path LEVEL_PATH, -l LEVEL_PATH
                        Path to a .json level container
```

### Interface
* Load a png spritesheet by clicking "Load Map Image"
* Load a json level by clicking "Load Json"
* Save a json level by clicking "export"
* modify the board width (x) and height (y) by using the buttons under the desired parameter
* The width (w) and height (h) of the tile
* The spacing between images on the x (s_x) and y (s_y) axis.
* Click a sprite on the left to select it
* Click on the grid to place it
* Right click to erase the tile
* Use WSAD to maneuver around the grid