import math


class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def toTup(self):
        return (self.x, self.y)

    def __abs__(self):
        return math.sqrt(self.x ** 2 + self.y ** 2)

    def __rdiv__(self, other):
        return Vector(self.x / other, self.y / other)

    def __truediv__(self, other):
        return Vector(self.x / other, self.y / other)

    def __div__(self, other):
        return Vector(self.x / other, self.y / other)

    def __mul__(self, other):
        return Vector(self.x * other, self.y * other)

    def __sub__(self, other):
        return Vector(self.x - other.x, self.y - other.y)

    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)

    def __neg__(self):
        return Vector(-self.x, -self.y)