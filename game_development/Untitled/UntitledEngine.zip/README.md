hi                                      

run with 

./bin/game

nice